<!DOCTYPE html>
<html lang="en">
<?php
    $conn = require_once('ConnectionDB.php');

    if (isset($_POST["sign"])) {

      $userid=$_POST["userid"];
      $userpassword=$_POST["userpassword"];
      $userphone=$_POST["userphone"];
      $useremail=$_POST["useremail"];

      $check="SELECT * FROM user WHERE userid='".$userid."'";//檢查帳號是不是有註冊過sql
      if(mysqli_num_rows(mysqli_query($conn,$check))==0){
          $sql = "INSERT INTO forwebproject.user(userid, userpassword, userphone, useremail)
              VALUES ('$userid', '$userpassword', '$userphone', '$useremail')";


          if (mysqli_query($conn, $sql)) {
            $message="註冊成功";
            echo "<script>alert('$message');window.location.href='Home_Page.php';</script>";
          } else {
            //echo "Failed!<br>";
            echo mysqli_errno($conn);
          }
          
      }else{ 
            $message="這個帳號已經有人使用";
            echo "<script>alert('$message');window.location.href='SignIn_Page.php';</script>";
           }
    }   
    mysqli_close($conn);
?>
</html>