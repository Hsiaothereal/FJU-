    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Custom styles for this template -->
    
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="generator" content="Mobirise v5.2.0, mobirise.com">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
    <link rel="shortcut icon" href="assets/images/mbr-121x147.png" type="image/x-icon">
    <meta name="description" content="">

    <link rel="stylesheet" href="mobiboot/tether.min.css">
    <link rel="stylesheet" href="mobiboot/bootstrap.min.css">
    <link rel="stylesheet" href="mobiboot/bootstrap-grid.min.css">
    <link rel="stylesheet" href="mobiboot/bootstrap-reboot.min.css">
    <link rel="stylesheet" href="mobiboot/style.css">
    <link rel="stylesheet" href="mobiboot/styles.css">
    <link rel="stylesheet" href="mobiboot/style2.css">
    <link rel="preload" as="style" href="mobiboot/mbr-additional.css">
    <link rel="stylesheet" href="mobiboot/mbr-additional2.css" type="text/css">
    <link rel="preload" as="style" href="mobiboot/mbr-additional3.css">
    