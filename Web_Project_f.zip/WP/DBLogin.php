<?php
session_start();
        function function_alert($message)
        {

            // Display the alert box  
            echo "<script>alert('$message');
            window.location.href='Login_Page.php';
            </script>";
            return false;
        }
        function login_success_alert($message) { 

            // Display the alert box  
            echo "<script>alert('$message');
            window.location.href='index_0.php';
            </script>";
        }
        $conn = require_once('ConnectionDB.php');
        $userid = $_POST["userid"];
        $password = $_POST["password"];

        $password_hash = password_hash($password, PASSWORD_DEFAULT);

        // Processing form data when form is submitted
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $sql6 = "SELECT * FROM forwebproject.user WHERE user.userid ='" . $userid . "'";
            $result = mysqli_query($conn, $sql6);
            $rs2 =  mysqli_fetch_assoc($result);
            if (mysqli_num_rows($result) == 1 && $password == $rs2["userpassword"]) {

                if($rs2["auth"]=="1"){
                    $_SESSION["admin_loggedin"] = true;
                    $_SESSION["username"] = $rs2["username"];
                    $_SESSION["userid"] = $userid;

                    login_success_alert("管理者登入成功");
                }elseif($rs2["auth"]=="0"){
                    $_SESSION["user_loggedin"] = true;
                    $_SESSION["username"] = $rs2["username"];
                    $_SESSION["userid"] = $userid;

                    login_success_alert("使用者登入成功");
                }
            } else {
                function_alert("帳號或密碼錯誤，請重新輸入!!");
            }
        } else {
            header("location:Login_Page.php");
        }
    
?>