<style>
    .nav-item a {
        font-size: 20px;
    }
</style>
<?php
session_start();
if (isset($_SESSION["user_loggedin"]) && $_SESSION["user_loggedin"] == true) { ?>
	<section class="menu cid-s48OLK6784" once="menu" id="menu1-h">

		<nav class="navbar navbar-dropdown navbar-fixed-top navbar-expand-lg">
			<div class="container">
				<div class="navbar-brand">
					<span class="navbar-logo">
						<a href="Home_Page.php">
							<img src="Image/fju_logo.png" style="height: 3.8rem;">
						</a>
					</span>
					<span class="navbar-caption-wrap"><a class="navbar-caption text-black text-primary display-2" href="Home_Page.php">活動管理系統</a></span>
				</div>
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
					<div class="hamburger">
						<span></span>
						<span></span>
						<span></span>
						<span></span>
					</div>
				</button>
				<div class="collapse navbar-collapse" id="navbarSupportedContent">
					<ul class="navbar-nav nav-dropdown nav-right" data-app-modern-menu="true">
						<li class="nav-item">
							<a class="nav-link link text-info text-primary display-4" href="Logout.php">登出</a>
						</li>
						<li class="nav-item">
							<a class="nav-link link text-info text-primary display-4" href="User_Information.php">會員資訊</a>
						</li>
					</ul>

				</div>
			</div>
		</nav>
	</section>
<?php } elseif (isset($_SESSION["admin_loggedin"]) && $_SESSION["admin_loggedin"] == true) { ?>
	<section class="menu cid-s48OLK6784" once="menu" id="menu1-h">

		<nav class="navbar navbar-dropdown navbar-fixed-top navbar-expand-lg">
			<div class="container">
				<div class="navbar-brand">
					<span class="navbar-logo">
						<a href="Home_Page.php">
							<img src="Image/fju_logo.png" style="height: 3.8rem;">
						</a>
					</span>
					<span class="navbar-caption-wrap"><a class="navbar-caption text-black text-primary display-2" href="Home_Page.php">活動管理系統</a></span>
				</div>
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
					<div class="hamburger">
						<span></span>
						<span></span>
						<span></span>
						<span></span>
					</div>
				</button>
				<div class="collapse navbar-collapse" id="navbarSupportedContent">
					<ul class="navbar-nav nav-dropdown nav-right" data-app-modern-menu="true">
						<li class="nav-item">
							<a class="nav-link link text-info text-primary display-4" href="Logout.php">登出</a>
						</li>
						<li class="nav-item">
							<a class="nav-link link text-info text-primary display-4" href="Admin_Information.php">會員資訊</a>
						</li>
						<li class="nav-item">
							<a class="nav-link link text-info text-primary display-4" href="index_admin.php">管理</a>
						</li>
					</ul>

				</div>
			</div>
		</nav>
	</section>
<?php } elseif (empty($_SESSION["user_loggedin"]) && empty($_SESSION["admin_loggedin"])) { ?>
	<section class="menu cid-s48OLK6784" once="menu" id="menu1-h">

		<nav class="navbar navbar-dropdown navbar-fixed-top navbar-expand-lg">
			<div class="container">
				<div class="navbar-brand">
					<span class="navbar-logo">
						<a href="Home_Page.php">
							<img src="Image/fju_logo.png" style="height: 3.8rem;">
						</a>
					</span>
					<span class="navbar-caption-wrap"><a class="navbar-caption text-black text-primary display-2" href="Home_Page.php">活動管理系統</a></span>
				</div>
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
					<div class="hamburger">
						<span></span>
						<span></span>
						<span></span>
						<span></span>
					</div>
				</button>
				<div class="collapse navbar-collapse" id="navbarSupportedContent">
					<ul class="navbar-nav nav-dropdown nav-right" data-app-modern-menu="true">
						<li class="nav-item">
							<a class="nav-link link text-info text-primary display-4" href="Login_Page.php">登入</a>
						</li>
						<li class="nav-item">
							<a class="nav-link link text-info text-primary display-4" href="SignIn_Page.php">註冊</a>
						</li>
					</ul>

				</div>
			</div>
		</nav>
	</section>
<?php } ?>