<head>
    <?php
    include "Link.php";
    ?>
    <title>Sign</title>
</head>

<body>
    <?php
    include "Nav_check.php";
    ?>
    <section class="form6 cid-sdiWxCzINU" id="form6-z" style="background-image: url(Image/004.jpg);background-size: cover;">
        <div class="mbr-overlay"></div>
        <div class="container">
            <div class="mbr-section-head">
                <h3 class="mbr-section-title mbr-fonts-style align-center mb-0 display-2"><a href="Change_Password_Page.php" class="text-primary">修改密碼</a></h3>

            </div>
            <div class="row justify-content-center mt-4">
                <div class="col-lg-8 mx-auto mbr-form" data-form-type="formoid">
                    <form action="" method="POST" class="mbr-form form-with-styler mx-auto">
                        <div class="dragArea row">
                            <div class="col-lg-12 col-md-12 col-sm-12 form-group">
                                <input type="text" name="Username" placeholder="Username" class="form-control">
                            </div>
                            <div class="col-lg-12 col-md-12 col-sm-12 form-group">
                                <input type="password" name="OldPassword" placeholder="OldPassword" class="form-control">
                            </div>
                            <div class="col-lg-12 col-md-12 col-sm-12 form-group">
                                <input type="password" name="NewPassword" placeholder="NewPassword" class="form-control">
                            </div>
                            <div class="col-auto mbr-section-btn align-center"><button type="submit" class="btn btn-primary display-4">確定修改<br></button></div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
    <?php
    include "footer.php";
    ?>
</body>

</html>