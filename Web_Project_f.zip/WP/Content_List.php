<!DOCTYPE html>

<html lang="en"> 

 <head>
    <?php
    include "Link.php";
    ?>
    <title>Your activity</title>

    <style>
        .row {
            line-height: 220px;
        }

        .mbr-section-head {
            margin-bottom: 20px;
        }

        img {
            height: 230px;
        }
    </style>
 </head>
 <body>
    <?php
    session_start();
    include "Nav_check.php";
    include "ConnectionDB.php";
    ?>

    <section class="features8 cid-sfahrEY6mC"  id="features9-16">
        <div class="container">
            <div class="mbr-section-head">
                <h4 class="mbr-section-title mbr-fonts-style align-center mb-0 display-2">
                    <strong><em><?php echo $_SESSION["userid"] ?>已報名的活動</em></strong></h4>
            </div>
             <?php
                    $conn = require_once('ConnectionDB.php');
                    $userid2=$_SESSION["userid"];
                    $sql = "SELECT * FROM forwebproject.useractivity WHERE useractivity.userid='$userid2'";
                    $result2 = mysqli_query($conn, $sql);
                    if (mysqli_num_rows($result2) > 0) {
                        while ($row = mysqli_fetch_assoc($result2)) {
            ?>
                    <div class="card">
                        <div class="card-wrapper">
                            <div class="row align-items-center">
                                <div class="col-12 col-md-4">
                                    <div class="image-wrapper">
                                        <img src="Image/007.jpg">
                                    </div>
                                </div>
                                <div class="col-12 col-md">
                                    <div class="card-box">
                                        <div class="row">
                                            <div class="col-md">
                                                <h6 class="card-title mbr-fonts-style display-5">
                                                    <strong><?php echo $row['activity_name'] ?></strong>
                                                </h6>
                                                <p class="mbr-text mbr-fonts-style display-7">
                                                    
                                                </p>
                                            </div>
                                            <div class="col-md-auto">
                                                <div class="mbr-section-btn">
                                                  <a href="" class="btn btn-primary display-4">取消報名</a>
                                                  <a href="" class="btn btn-primary display-4">提醒我!<br></a>
                                                </div>
                                            </div>
                                            <div></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
            <?php
                        }
                    }
            ?>
                    <div class="card">
                        <div class="card-wrapper">
                            <div class="row align-items-center">
                                <div class="col-12 col-md-4">
                                    <div class="image-wrapper">
                                        <img src="Image/007.jpg">
                                    </div>
                                </div>
                                <div class="col-12 col-md">
                                    <div class="card-box">
                                        <div class="row">
                                            <div class="col-md">
                                                <h6 class="card-title mbr-fonts-style display-5">
                                                    <strong>我國外交政策</strong>
                                                </h6>
                                                <p class="mbr-text mbr-fonts-style display-7">
                                                    
                                                </p>
                                            </div>
                                            <div class="col-md-auto">
                                                <div class="mbr-section-btn">
                                                <a href="" class="btn btn-primary display-4">取消報名</a>
                                                <a href="" class="btn btn-primary display-4">提醒我!<br></a>
                                                </div>
                                            </div>
                                            <div></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
    </section>
    <?php
       include "footer.php";
    ?>
 </body>
</html>