<!-- Footer -->
<footer class="page-footer font-small blue">

  <!-- Copyright -->
  <div class="footer-copyright text-center py-3" style="background-color: #ffe885; position:fixed; bottom:0; width:100%;">© 2020 Copyright:
    <a href="">資管四乙 蕭裕瑾 期中作業</a>
  </div>
  <!-- Copyright -->

</footer>
<!-- Footer -->