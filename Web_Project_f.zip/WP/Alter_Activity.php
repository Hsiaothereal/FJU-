<!DOCTYPE html>
<html lang="en">

<head>
    <?php
    include "Link.php";
    ?>
    <title>修改活動</title>
</head>

<body>
    <?php
    include "Nav_check.php";

    ?>
    <section class="form6 cid-sdiWxCzINU" id="form6-z" style="background-image: url(Image/004.jpg);background-size: cover;">
        <div class="mbr-overlay"></div>
        <div class="container">
            <div class="mbr-section-head">
                <h3 class="mbr-section-title mbr-fonts-style align-center mb-0 display-2"><a href="index_admin.php" class="text-primary">修改活動</a></h3>

            </div>
            <div class="row justify-content-center mt-4">
                <div class="col-lg-8 mx-auto mbr-form" data-form-type="formoid">
                    <?php
                    $conn = require_once('ConnectionDB.php');
                    $activity_id = $_POST["update"];
                    $sql = "SELECT * FROM forwebproject.activity WHERE activity_id=$activity_id";
                    $result = mysqli_query($conn, $sql);
                    if (mysqli_num_rows($result) > 0) {
                        while ($row = mysqli_fetch_assoc($result)) {
                    ?>
                            <form action="index_admin.php" method="post" class="mbr-form form-with-styler mx-auto">
                                <div class="dragArea row">
                                    <div class="col-lg-12 col-md-12 col-sm-12 form-group">
                                        活動編號:<input type="number" name="activityid" value=<?php echo $row['activity_id'] ?> class="form-control" readonly>
                                    </div>
                                    <div class="col-lg-12 col-md-12 col-sm-12 form-group">
                                        活動名稱:<input type="text" name="activityname" value=<?php echo $row['activity_name'] ?> class="form-control">
                                    </div>
                                    <div class="col-lg-12 col-md-12 col-sm-12 form-group">
                                        活動日期:<input type="date" name="activitydate" value=<?php echo $row['activity_date'] ?> class="form-control">
                                    </div>
                                    <div class="col-lg-12 col-md-12 col-sm-12 form-group">
                                        活動時間:<input type="time" name="activitytime" value=<?php echo $row['activity_time'] ?> class="form-control">
                                    </div>
                                    <div class="col-lg-12 col-md-12 col-sm-12 form-group">
                                        活動地點:<input type="text" name="activitylocation" value=<?php echo $row['activity_location'] ?> class="form-control">
                                    </div>
                                    <div class="col-lg-12 col-md-12 col-sm-12 form-group">
                                        活動講者:<input type="text" name="activitylecturer" value=<?php echo $row['activity_lecturer'] ?> class="form-control">
                                    </div>
                                    <div class="col-auto mbr-section-btn align-center">
                                        <input type="submit" class="btn btn-primary display-4" name="update_btn2" value="修改活動"><br>
                                    </div>
                                </div>
                            </form>
                        <?php
                        }
                    }
                        ?>    
                </div>
            </div>
        </div>
    </section>
<?php
      include "footer.php";
?>
</body>

</html>