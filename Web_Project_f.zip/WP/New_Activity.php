<!DOCTYPE html>
<html lang="en">

<head>
    <?php
    include "Link.php";
    ?>
    <title>Sign</title>
</head>

<body>
    <?php
    include "Nav_check.php";
    ?>
    <section class="form6 cid-sdiWxCzINU" id="form6-z" style="background-image: url(Image/004.jpg);background-size: cover;">
        <div class="mbr-overlay"></div>
        <div class="container">
            <div class="mbr-section-head">
                <h3 class="mbr-section-title mbr-fonts-style align-center mb-0 display-2"><a href="New_Activity.php" class="text-primary">新增活動</a></h3>

            </div>
            <div class="row justify-content-center mt-4">
                <div class="col-lg-8 mx-auto mbr-form">
                    <form action="New_Activity2.php" method="POST" class="mbr-form form-with-styler mx-auto">
                        <div class="dragArea row">
                            <div class="col-lg-12 col-md-12 col-sm-12 form-group">
                                <input type="number" name="activitycode" placeholder="活動代碼" class="form-control">
                            </div>
                            <div class="col-lg-12 col-md-12 col-sm-12 form-group">
                                <input type="text" name="actname" placeholder="活動名稱" class="form-control">
                            </div>
                            <div class="col-lg-12 col-md-12 col-sm-12 form-group">
                                <input type="date" name="date" class="form-control">
                            </div>
                            <div class="col-lg-12 col-md-12 col-sm-12 form-group">
                                <input type="time" name="time" class="form-control">
                            </div>
                            <div class="col-lg-12 col-md-12 col-sm-12 form-group">
                                <input type="text" name="location" placeholder="地點" class="form-control">
                            </div>
                            <div class="col-lg-12 col-md-12 col-sm-12 form-group">
                                <input type="text" name="lecturer" placeholder="活動講師" class="form-control">
                            </div>
                            <div class="col-auto mbr-section-btn align-center">
                                <button type="submit" name="submit" class="btn btn-primary display-4">新增<br></button>
                            </div>
                            <div class="col-auto mbr-section-btn align-center">
                                <button type="submit2" name="submit2" class="btn btn-primary display-4">回首頁<br></button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
    <?php
    include "footer.php";
    ?>
</body>

</html>