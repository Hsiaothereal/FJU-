<?php
    define('severname', 'localhost');
    define('username','root');
    define('password','hsiao1999');
    define('dbname','forwebproject');

    $link = mysqli_connect(severname, username, password, dbname);
    // 輸入中文也OK的編碼
    mysqli_query($link, 'SET NAMES utf8');

    if($link === false){
        die("ERROR: Could not connect. " . mysqli_connect_error());
    }
    else{
    
        return $link;
        
    }
?>
