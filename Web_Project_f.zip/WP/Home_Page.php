<!DOCTYPE html>

<html lang="en">

<head>
    <?php
    include "Link.php";
    ?>
    <title>Home</title>
</head>

<body>
    <?php
       include "Nav_check.php";
       

    ?>
    
    <section class="header1 cid-s48MCQYojq mbr-fullscreen mbr-parallax-background" id="header1-f" style="background-image: url(Image/001.jpg);background-size: cover;">
        <div class="mbr-overlay" style="opacity: 0.5; background-color: rgb(255, 255, 255);"></div>
        <div class="align-center container">
            <div class="row justify-content-center">
                <div class="col-12 col-lg-8">
                    <h1 class="mbr-section-title mbr-fonts-style mb-3 display-1"><strong>天主教輔仁大學</strong></h1>

                    <p class="mbr-text mbr-fonts-style display-7"><em><strong>活動管理系統</strong></em></p>
                    <div class="mbr-section-btn mt-3"><a class="btn btn-success display-4" href="index_0.php">看活動!!</a> <a class="btn btn-success-outline display-4" href="SignIn_Page.php">註冊去!!</a></div>
                </div>
            </div>
        </div>
    </section>
    <?php
    include "footer.php";
    ?>
</body>

</html>