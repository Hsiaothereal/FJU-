<!DOCTYPE html>
<html lang="en">

<head>
    <?php
    include "Link.php";
    ?>
    <style>
        .cid-sfmlrIaw1j {
            padding-top: 90px;
            padding-bottom: 90px;
            background-image: url(Image/016.jpg);
        }

        @media (min-width: 992px) {
            .cid-sfmlrIaw1j .mbr-figure {
                padding-right: 4rem;
            }
        }
    </style>
    <title>UserInformation</title>


</head>

<body>
    <?php
    include "Nav_check.php";
    ?>

    <section class="services2 cid-sfmlrIaw1j mbr-parallax-background" id="services2-1a">
        <!---->

        <!---->
        <!--Overlay-->
        <div class="mbr-overlay" style="opacity: 0.5; background-color: rgb(255, 255, 255);">
        </div>
        <!--Container-->
        <div class="container">
            <div class="col-md-12">
                <div class="media-container-row">
                    <div class="mbr-figure" style="width: 50%;">
                        <img src="Image/015.jpg">
                    </div>
                    <div class="align-left aside-content">
                        <h2 class="mbr-title pt-2 mbr-fonts-style display-2">Tommy</h2>
                        <div class="mbr-section-text">
                            <p class="mbr-text text1 pt-2 mbr-light mbr-fonts-style display-7">電&nbsp; &nbsp;子&nbsp; &nbsp; 信&nbsp; &nbsp;箱 :<br>權&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;限 : 一般使用者<br><br></p>
                            <p class="mbr-text text2 pt-4 mbr-light mbr-fonts-style display-2">這月參加活動數 : 2</p>
                        </div>
                        <!--Btn-->
                        <div class="mbr-section-btn pt-3 align-center"><a href="Delete_Account.php" class="btn btn-warning display-4">刪除帳號</a> <a href="Change_Password_Page.php" class="btn btn-warning display-4">修改密碼</a></div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php
    include "footer.php";
    ?>

</body>

</html>