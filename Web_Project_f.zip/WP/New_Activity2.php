<?php
$conn = require_once('ConnectionDB.php');

if (isset($_POST["submit"])) {
  $code = $_POST["activitycode"];
  $actname = $_POST["actname"];
  $date = $_POST["date"];
  $time = $_POST["time"];
  $location = $_POST["location"];
  $lecturer = $_POST["lecturer"];

  $sql = "insert into forwebproject.activity(activity_id, activity_name, activity_date, activity_time, activity_location, activity_lecturer)
       values ($code, '$actname', '$date', '$time', '$location', '$lecturer')";
  if (mysqli_query($conn, $sql)) {
    header('Location:New_Activity.php');
  } else {
    echo "Failed!<br>";
    echo mysqli_errno($conn);
  }
  mysqli_close($conn);
}else{ 
  echo "操作錯誤!";
  header('Location:index_0.php');
}

if(isset($_POST["submit2"])){
      header('Location:index_0.php');
}

?>