<!DOCTYPE html>

<html lang="en">

<head>
    <?php
    include "Link.php";
    ?>
    <title>活動管理系統</title>
</head>

<body>
    <?php
    session_start();
    include "Nav_check.php";
    
    $searchtxt = $_GET["searchtxt"];
    $conn = require_once('ConnectionDB.php');
    if(isset($_SESSION["user_loggedin"]) && $_SESSION["user_loggedin"] == true or isset($_SESSION["admin_loggedin"]) && $_SESSION["admin_loggedin"] == true ){
    ?>
    <section class="features4 cid-sdiSAPFc3A" id="features4-r" style="background-image: url(Image/background3.jpg);">

        <div class="mbr-overlay"></div>
        <div class="container">
            <div class="mbr-section-head" style="text-align: right;">
                <h4 class="mbr-section-title mbr-fonts-style align-center mb-0 display-2">
                    <strong><em>活動內容</em></strong></h4>
                <form action="index_0.php" method=get>
                    <input class="form-control mr-sm-2" style="display: inline-block;width: 21%" type=hidden name="method" value="query"> <!-- 現在method變數值是query，避免搜尋後值消失，所以用hidden再傳一次值 -->
                    <p align=right><input type=text name="searchtxt" placeholder="Search...." value=<?php echo $searchtxt; ?>><input class="btn btn-outline-success my-2 my-sm-0" type=submit value="搜尋活動"></p>
                </form>
            </div>
            <div class="row mt-4">
                <?php
                if (empty($searchtxt)) {
                    $sql = "SELECT * FROM forwebproject.activity";
                    $result2 = mysqli_query($conn, $sql);
                    if (mysqli_num_rows($result2) > 0) {
                        while ($row = mysqli_fetch_assoc($result2)) {
                ?>
                            <div class="item features-image сol-12 col-md-6 col-lg-4">
                                <div class="item-wrapper">
                                    <div class="item-img">
                                        <img src="Image/007.jpg">
                                    </div>
                                    <div class="item-content">
                                        <h5 class="item-title mbr-fonts-style display-5"><strong><?php echo $row['activity_name'] ?></strong></h5>
                                        <h6 class="item-subtitle mbr-fonts-style mt-1 display-7"><?php echo $row['activity_lecturer'] ?></h6>
                                        <p class="mbr-text mbr-fonts-style mt-3 display-7">活動日期：<?php echo $row['activity_date'] ?>
                                            <br>活動時間：<?php echo $row['activity_time'] ?>
                                            <br>活動地點：<?php echo $row['activity_location'] ?><br>活動代碼：<?php echo $row['activity_id'] ?><br><br>
                                        </p>
                                    </div>
                                    <div class="mbr-section-btn item-footer mt-2">
                                        <div class="mbr-section-btn item-footer mt-2">
                                            <form method="post">
                                                <input type="hidden" name="activity_id" value="<?php echo $row['activity_id'] ?>">
                                                <input type="hidden" name="activity_name" value="<?php echo $row['activity_name'] ?>">
                                                <input type="submit" class="btn item-btn btn-black display-7" value="我要報名!" name="apply_btn">
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php
                        }
                    } else { ?>
                        <tr>
                            <td colspan="3"><?php echo "null" ?></td>

                        </tr>
                    <?php
                    }
                } else {
                    $sql = "select * from activity where activity_id like '%" . $searchtxt . "%' or activity_name like '%" . $searchtxt . "%'";
                    $rs = mysqli_query($link, $sql);
                    while ($record = mysqli_fetch_row($rs)) {
                    ?>
                        <div class="item features-image сol-12 col-md-6 col-lg-4">
                            <div class="item-wrapper">
                                <div class="item-img">
                                    <img src="Image/008.jpg">
                                </div>
                                <div class="item-content">
                                    <h5 class="item-title mbr-fonts-style display-5"><strong><?php echo $record[1] ?></strong></h5>
                                    <h6 class="item-subtitle mbr-fonts-style mt-1 display-7">
                                        <?php echo $record[5] ?></h6>
                                    <p class="mbr-text mbr-fonts-style mt-3 display-7">活動日期：<?php echo $record[2] ?>
                                        <br>活動時間：<?php echo $record[3] ?>
                                        <br>活動地點：<?php echo $record[4] ?><br>活動代碼：<?php echo $record[0] ?><br>&nbsp;<br>
                                    </p>
                                </div>
                                <div class="mbr-section-btn item-footer mt-2">
                                    <div class="mbr-section-btn item-footer mt-2">
                                        <form method="post">
                                            <input type="hidden" name="activity_id" value="<?php echo $row['activity_id'] ?>">
                                            <input type="hidden" name="activity_name" value="<?php echo $row['activity_name'] ?>">
                                            <input type="submit" class="btn item-btn btn-black display-7" value="我要報名!" name="apply_btn">
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                <?php
                    }
                }
                ?>
            </div>
        </div>

    </section>
    <?php
    } else {
        function_alert2("請先登入!!");
    }
    
    ?>

    <?php
    //報名活動
    if (isset($_POST["apply_btn"])) {
        $userid2 = $_SESSION["userid"];
        $activity_id = $_POST["activity_id"];
        $activity_name = $_POST["activity_name"];
        $sql2 = "INSERT INTO forwebproject.useractivity(userid, activity_id, activity_name) 
              VALUES('$userid2', '$activity_id', '$activity_name')";
        if (mysqli_query($conn, $sql2)) {
            function_alert3("活動報名成功!!");
        } else {
            function_alert3("活動報名失敗!!請嘗試重新報名!!");
        }
    }
    function function_alert2($message)//尚未登入
    {

        // Display the alert box  
        echo "<script>alert('$message');
         window.location.href='Home_Page.php';
        </script>";
        return false;
    }
    function function_alert3($message)//活動報名失敗
    {

        // Display the alert box  
        echo "<script>alert('$message');
         window.location.href='index_0.php';
        </script>";
        return false;
    }
      include "footer.php";
    ?>
</body>

</html>