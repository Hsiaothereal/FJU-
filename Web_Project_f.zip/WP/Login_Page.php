<!DOCTYPE html>
<html lang="en">

<head>
    <?php
    include "Link.php";
    ?>
    <title>Login</title>
</head>

<body>
    <?php
    session_start();
     include "Nav_check.php";

    // Initialize the session
    

    // Check if the user is already logged in, if yes then redirect him to welcome page
    if (isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true) {
        header("location: index_0.php");
        exit;  
    }else{
        
    }

    ?>
    <section class="form6 cid-sdiWxCzINU" id="form6-z" style="background-image: url(Image/004.jpg);background-size: cover;padding-top: 7rem;padding-bottom: 7rem;">
        <div class="mbr-overlay"></div>
        <div class="container">
            <div class="mbr-section-head">
                <h3 class="mbr-section-title mbr-fonts-style align-center mb-0 display-2"><a href="Login_Page.php" class="text-primary">登入</a></h3>

            </div>
            <div class="row justify-content-center mt-4">
                <div class="col-lg-8 mx-auto mbr-form" data-form-type="formoid">
                    <form action="DBLogin.php" method="POST" class="mbr-form form-with-styler mx-auto" data-form-title="Form Name"><input type="hidden" name="email" data-form-email="true" value="JPSSSeaB30FpGqRO5K8F7b3/T6s39A7vRDzQRQSyO3ECXpTO91U2tjT5Xurz2TfLa9JIzcM1m3cbU/cxlEHdr6k70NJKQg8/5EYSfjQwGVj6I+39dC0C2fuHUpEAkdBQ">
                        <div class="dragArea row">
                            <div class="col-lg-12 col-md-12 col-sm-12 form-group">
                                <input type="text" name="userid" placeholder="輸入帳號" class="form-control">
                            </div>
                            <div class="col-lg-12 col-md-12 col-sm-12 form-group" data-for="email">
                                <input type="password" name="password" placeholder="輸入密碼" class="form-control">
                            </div>

                            <div class="col-auto mbr-section-btn align-center"><input type="submit" name="login"  class="btn btn-primary display-4">登入</button></div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
    <?php
    include "footer.php";
    ?>
</body>

</html>